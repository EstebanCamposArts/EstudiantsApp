<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Panel de Control EstudiantsApp</title>
  
  <script src="https://identity.netlify.com/v1/netlify-identity-widget.js"></script>
  
  <script src="https://unpkg.com/decap-cms@^3.0.0/dist/decap-cms.js"></script>
</head>
<body>
    <script>
        if (window.netlifyIdentity) {
            netlifyIdentity.on("init", user => {
                if (!user) {
                    // Forzar el widget de inicio de sesión si no hay usuario logueado
                    netlifyIdentity.open();
                }
            });
        }
    </script>
</body>
</html>